function ETL(){
    this.output = {};
}
ETL.prototype.transform = function(input){
    var key=Object.keys(input);
    console.log(input);
    console.log(key[0]);
   for (var index in key) {
       if (key.hasOwnProperty(index)) {
        for (var index in inputArray) {
            if (inputArray.hasOwnProperty(index)) {
                var element = inputArray[index];
                this.output[element.toLowerCase()] = parseInt(key);
                console.log(this.output);
            }
        }
           
       }
   }
    var inputArray=input[key];

   
    return this.output;
}
module.exports = ETL;